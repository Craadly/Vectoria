// server.js

// --- Dependencies ---
// Import required modules from your project and npm packages.
const express = require('express');
const cors = require('cors');
const path = require('path');
const config = require('./config/env');
const apiRoutes = require('./routes/api');
const { startCleanup } = require('./utils/cleanup');

// --- App Initialization ---
// Create an instance of the Express application.
const app = express();

// --- Middleware Setup ---
// Increase the JSON payload limit to handle potentially large data, like images.
app.use(express.json({ limit: '50mb' }));
// Enable Cross-Origin Resource Sharing (CORS) to allow requests from your frontend.
app.use(cors());

// --- Static File Serving ---
// Serve the main 'public' folder for static assets like index.html.
// Note: This will be less important once you fully switch to the Next.js frontend.
app.use(express.static('public')); 
// Serve the 'temp' folder to make generated images and SVGs accessible via a URL.
app.use('/temp', express.static(path.join(__dirname, 'temp')));

// --- API Route Handling ---
// All requests starting with '/api' will be handled by the router defined in './routes/api.js'.
// This keeps your server file clean and organized.
app.use('/api', apiRoutes);

// --- Server Start ---
// Start the server and listen for connections on the port defined in your config.
app.listen(config.PORT, () => {
    // Log a confirmation message to the console with key configuration details.
    console.log(`
    ╔════════════════════════════════════════════════════════════╗
    ║                                                            ║
    ║               🎨 VECTORIA.AI SERVER 🎨                     ║
    ║                                                            ║
    ╚════════════════════════════════════════════════════════════╝
    
    🚀 Server running at http://localhost:${config.PORT}
    
    📋 PIPELINE: Gemini -> Imagen -> Recraft
    
    🔌 SERVICE STATUS:
        - Gemini API Key:    ${config.GEMINI_API_KEY ? '✅ Loaded' : '❌ MISSING'}
        - Recraft API Key:   ${config.RECRAFT_API_KEY ? '✅ Loaded' : '❌ MISSING'}
        - Google Project ID: ${config.GOOGLE_PROJECT_ID ? '✅ Loaded' : '❌ MISSING'}
    `);
    
    // Initialize the periodic cleanup utility for the temp directory.
    startCleanup();
});
